
import torch
from matplotlib.gridspec import GridSpec

from torch.utils.data import DataLoader

from tools.timeseries_dataset import TimeSeriesDataset
from viz.visualization import visualize_predictions, plot_training_history

from pipeline.train_eval import train_epoch, evaluate
from pipeline.nncltllm import NNCLTLLM

import json
import pandas as pd

import sys

######################## PARSER
import argparse

parser = argparse.ArgumentParser(description = "********") 

parser.add_argument("--file", "-f", type = str, help="csv file",) 
# parser.add_argument("--name", type = str, help="name of study", default = "Etude des valeurs") 
# parser.add_argument("--patch_len", type = int, help="patch length", default = 4) 
# parser.add_argument("--stride", type = int, help="stride for kernel", default = 1) 
# parser.add_argument("--nprotype", type = int, help="num prototype for TCSTP", default = 1000) 
# parser.add_argument("--support", type = int, help="support set for TCSTP", default = 100) 
# parser.add_argument("--topk", type = int, help="number of neighboor", default = 5) 
# parser.add_argument("--nllm", type = int, help="number of layer for llm model", default = 3) 
# parser.add_argument("--lr", type = float, help="learning rate", default = 1e-3) 
# parser.add_argument("--batchs", type = int, type = int, help="batch size of training", default = 8 
# parser.add_argument("--lambda", type = float, help="regularisation for optimizer", default = 1.1) 
# parser.add_argument("--decay", type = float, help="optimizer param", default = 0.0004) 
# parser.add_argument("--inputlen", type = int, help="input window for time serie", default = 10) 
# parser.add_argument("--predlen", type = int, help="number of step for pred: T+1, T+2, ...", default = 1) 
# parser.add_argument("--channels", type = list, help="Channels names in the dataset",) 

args = parser.parse_args() 
###############################

if __name__ == "__main__":

	# Configuration
	try:
		with open('config.json', 'r') as json_file:
			config = json.load(json_file)
			config = config['config']
	except FileNotFoundError:
		print("Error: The file 'data.json' was not found.")
		sys.exit(1)
	
	device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
	print(f"Utilisation de: {device}")
	
	# Name
	print(f"Lancement de la configuration: {config['name']}")
	
	# Hyperparamètres
	input_length = config['input_length'] # T
	pred_length = config['pred_length']
	batch_size = config['batch_size']
	num_epochs = 10
	learning_rate = config['learning_rate']
	lambda_weight = config['lambda_weight']
	
	# Pour visualiztion
	channel_names = config['channel_names']
	num_channels = len(channel_names)  # Nombre de variables (multivariées)
	
	# Charger les données
	try:
		with open('config.json', 'r') as json_file:
			df = pd.read_csv(args.file)
	except FileNotFoundError:
		print("Error: The data file is missing.")
		sys.exit(1)
	
	train_dataset = TimeSeriesDataset(df.loc[:int(len(df)*.70), channel_names].values, input_length, 1) # prendre 80%
	val_dataset	  = TimeSeriesDataset(df.loc[int(len(df)*.70):len(df), channel_names].values, input_length, 1) # prendre 20% - input_length série pred
	
	# Créer les datasets
	train_loader = DataLoader(train_dataset, batch_size = batch_size, shuffle = True) # avec Shuffle = FALSE, Le modèle voit toujours les mêmes combinaisons → overfitting !
	val_loader = DataLoader(val_dataset, batch_size = batch_size, shuffle = False)	  # Validation ne pas mélanger les batchs
	
	print(f"Nombre de samples d'entraînement: {len(train_dataset)}")
	print(f"Nombre de samples de validation: {len(val_dataset)}")
	
	# Initialiser le modèle
	print("\nInitialisation du modèle NNCL-TLLM...")
	model = NNCLTLLM(
		num_channels=num_channels,
		input_length=input_length,
		pred_length=pred_length,
		patch_len = config['patch_len'], # NE PEUT PAS ETRE PLUS GRAND QUE LE TIMESTAMSP T
		stride = config['stride'],
		num_prototypes = config['num_prototypes'],
		support_set_size = config['support_set_size'],
		top_k = config['top_k'],
		num_llm_layers = config['num_llm_layers'],
		freeze_llm=True
	).to(device)
	
	# Compter les paramètres
	total_params = sum(p.numel() for p in model.parameters())
	trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
	print(f"Paramètres totaux: {total_params:,}")
	print(f"Paramètres entraînables: {trainable_params:,}")
	
	# Optimizer
	optimizer = torch.optim.AdamW(
		filter(lambda p: p.requires_grad, model.parameters()),
		lr=learning_rate,
		weight_decay = config['weight_decay']
	)
	
	# Scheduler
	scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
		optimizer,
		T_max=num_epochs
	)
	
	# Historique d'entraînement
	history = {
		'train_loss': [],
		'train_forecast_loss': [],
		'train_proto_loss': [],
		'train_nncl_loss': [],
		'val_mse': [],
		'val_mae': []
	}
	
	# Boucle d'entraînement
	print("\n" + "="*70)
	print("DÉBUT DE L'ENTRAÎNEMENT")
	print("="*70)
	
	
	
	logs = []
	
	best_val_mse = float('inf')
	
	for epoch in range(num_epochs):
		print(f"\nÉpoque {epoch+1}/{num_epochs}")
		print("-" * 70)
		
		# Entraînement
		train_metrics = train_epoch(
			model, train_loader, optimizer, device, lambda_weight
		)
		
		# Validation
		val_metrics = evaluate(model, val_loader, device)
		
		# Scheduler step
		scheduler.step()
		
		# Sauvegarder l'historique
		history['train_loss'].append(train_metrics['total_loss'])
		history['train_forecast_loss'].append(train_metrics['forecast_loss'])
		history['train_proto_loss'].append(train_metrics['proto_loss'])
		history['train_nncl_loss'].append(train_metrics['nncl_loss'])
		history['val_mse'].append(val_metrics['mse'])
		history['val_mae'].append(val_metrics['mae'])
		
		# Affichage des métriques
		print(f"Train - Loss: {train_metrics['total_loss']:.4f} | "
			f"Forecast: {train_metrics['forecast_loss']:.4f} | "
			f"Proto: {train_metrics['proto_loss']:.4f} | "
			f"NNCL: {train_metrics['nncl_loss']:.4f}")
		print(f"Val	  - MSE: {val_metrics['mse']:.4f} | "
			f"MAE: {val_metrics['mae']:.4f}")
			
		# Sauvegarder le meilleur modèle + hyperparams
		if val_metrics['mse'] < best_val_mse:
			best_val_mse = val_metrics['mse']
			checkpoint = {
			'model_state_dict': model.state_dict(), # Poids du modèle
			'hyperparameters': {
				'num_channels': num_channels,
				'input_length': input_length,
				'pred_length': pred_length,
				'patch_len': model.patch_len,
				'stride': model.stride,
				'num_prototypes': model.num_prototypes,
				'support_set_size': model.support_set_size,
				'top_k': model.top_k,
				'num_llm_layers': model.num_llm_layers,
				'embedding_dim': 768,
			},
			'channel_names': channel_names,
			'best_val_mse': best_val_mse,
			'epoch': epoch
			}
			torch.save(checkpoint, 'best_nncl_tllm_model.pt')
			print(f"✓ Meilleur modèle sauvegardé (MSE: {best_val_mse:.4f})")
			
		# Logs entrainement
		logs.append([epoch+1, round(train_metrics['total_loss'], 4), round(train_metrics['proto_loss'], 4), round(train_metrics['nncl_loss'], 4), ], round(val_metrics['mse'], 4), round(val_metrics['mae'], 4))
		
	# Sauvegarder logs entrainement
	pd.DataFrame(logs, columns = ['epoch', 'train_loss', 'Proto', 'NNCL', 'val_mse', 'val_mae']).to_csv("results/train_log.csv")
	
	print("\n" + "="*70)
	print("ENTRAÎNEMENT TERMINÉ")
	print(f"Meilleure MSE de validation: {best_val_mse:.4f}")
	print("="*70)
	
	# Visualisation de l'historique d'entraînement
	print("\nGénération des visualisations...")
	plot_training_history(history, save_path='training_history.png')
	
	# Charger le meilleur modèle pour l'évaluation finale
	print("\nChargement du meilleur modèle pour l'évaluation finale...")
	#model.load_state_dict(torch.load('best_nncl_tllm_model.pt'))
	# Charger le checkpoint
	checkpoint = torch.load('best_nncl_tllm_model.pt', map_location=device)
	hyperparameters = checkpoint['hyperparameters']
	channel_names = checkpoint.get('channel_names', None)
	model.load_state_dict(checkpoint['model_state_dict'])
	
	# Évaluation finale sur le jeu de validation
	final_val_metrics = evaluate(model, val_loader, device)
	
	print("\n" + "="*70)
	print("RÉSULTATS FINAUX")
	print("="*70)
	print(f"MSE finale: {final_val_metrics['mse']:.6f}")
	print(f"MAE finale: {final_val_metrics['mae']:.6f}")
	
	pd.DataFrame([[round(final_val_metrics['mse'], 6), round(final_val_metrics['mae'], 6)]], columns = ['MSE', 'MAE',]).to_csv("results/resultats_finaux.csv")
	
	# Visualiser les prédictions
	#channel_names = ['Sinusoïde', 'Cosinusoïde', 'Basse fréquence']
	print(f"- inputs : {final_val_metrics['inputs'].shape}")
	print(f"- predictions: {final_val_metrics['predictions'].shape}")
	print(f"- ground_truths: {final_val_metrics['ground_truths'].shape}")
	
	visualize_predictions(
		inputs=final_val_metrics['inputs'],
		predictions=final_val_metrics['predictions'],
		ground_truths=final_val_metrics['ground_truths'],
		num_samples=4,
		channel_names=channel_names,
		save_path='predictions_multivariate.png'
	)
	
	print("\n" + "="*70)
	print("ANALYSE PAR CANAL")
	print("="*70)
	
	logs = [] # reset
	
	# Calculer les métriques par canal
	for c in range(num_channels):
		preds_channel = final_val_metrics['predictions'][:, c, :]
		truth_channel = final_val_metrics['ground_truths'].unsqueeze(2)[:, c, :] if len(final_val_metrics['ground_truths'].shape) == 2 else final_val_metrics['ground_truths'][:, c, :]
		
		mse_channel = F.mse_loss(preds_channel, truth_channel).item()
		mae_channel = F.l1_loss(preds_channel, truth_channel).item()
		
		print(f"\n{channel_names[c]}:")
		print(f"  MSE: {mse_channel:.6f}")
		print(f"  MAE: {mae_channel:.6f}")
		
		logs.append([channel_names[c], round(mse_channel, 6), round(mae_channel, 6)])
		
	# Sauvegarder logs resultat par canal
	pd.DataFrame(logs, columns = ['canal', 'mse', 'mae']).to_csv("results/canal_log.csv")
	
	print("\n✓ Toutes les visualisations ont été générées avec succès!")
	print("	 - training_history.png: Courbes d'apprentissage")
	print("	 - predictions_multivariate.png: Visualisation des prédictions")
	print("	 - best_nncl_tllm_model.pt: Meilleur modèle sauvegardé")
	
	# Exemple d'utilisation pour la prédiction sur de nouvelles données
	print("\n" + "="*70)
	print("EXEMPLE DE PRÉDICTION SUR DE NOUVELLES DONNÉES")
	print("="*70)
	
	# Générer une nouvelle séquence
	"""
	new_time = np.linspace(120, 125, 600)
	new_data = np.column_stack([
		np.sin(new_time) + np.random.randn(600) * 0.1,
		np.cos(new_time * 1.5) + np.random.randn(600) * 0.1,
		np.sin(new_time * 0.5) * 2 + np.random.randn(600) * 0.15
	])
	"""
	
	# Prendre les input_length derniers points comme entrée
	new = df.loc[-input_length:, channel_names].values # Prender les 10 dernières
	new_input = torch.FloatTensor(new[-input_length:].T).unsqueeze(0).to(device)  # (1, C, T)
	
	model.eval()
	with torch.no_grad():
		new_pred, _ = model(new_input)
		
	print(f"Shape de l'entrée: {new_input.shape}")
	print(f"Shape de la prédiction: {new_pred.shape}")
	print(f"\nPrédiction effectuée avec succès!")
	
	# Visualiser cette prédiction
	fig, axes = plt.subplots(num_channels, 1, figsize=(14, 6*num_channels))
	if num_channels == 1:
		axes = [axes]
		
	for c in range(num_channels):
		ax = axes[c]
		
		# Historique
		hist_time = np.arange(input_length)
		ax.plot(hist_time, new_input[0, c].cpu().numpy(),
			label='Historical', color='blue', linewidth=1.5)
			
		pred_time = np.arange(input_length, input_length + pred_length)
		# Tracer la prédiction
		if pred_length == 1:
			# Un seul point : utiliser scatter ou plot avec marker
			ax.scatter(pred_time, new_pred[0, c].cpu().numpy(),
						  label='Prediction', color='red', s=100, marker='*', zorder=5)
						  
			# Ajouter valeur sur le point
			ax.text(x = pred_time, y = new_pred[0, c].cpu().item() + 25, s = "%d" %new_pred[0, c].cpu().item(), ha="center") # décaler en haut le label de +25
		else:
			# Tracer la Prédiction
			ax.plot(pred_time, new_pred[0, c].cpu().numpy(),
					label='Prediction', color='red', linewidth=2, linestyle='--')
					
		# Ligne verticale
		ax.axvline(x=input_length, color='gray', linestyle=':', alpha=0.5)
		
		ax.set_title(f'{channel_names[c]} - Nouvelle Prédiction')
		ax.set_xlabel('Time Steps')
		ax.set_ylabel('Value')
		ax.legend()
		ax.grid(True, alpha=0.3)
		
	plt.tight_layout()
	plt.savefig('new_prediction_example.png', dpi=150, bbox_inches='tight')
	print("\n✓ Exemple de prédiction sauvegardé: new_prediction_example.png")
	plt.close()
	
	print("\n" + "="*70)
	print("PIPELINE COMPLET TERMINÉ AVEC SUCCÈS!")
	print("="*70)