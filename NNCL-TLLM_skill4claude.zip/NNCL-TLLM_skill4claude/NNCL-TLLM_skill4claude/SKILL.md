---
name: time-series-nncltllm-prediction
description: "Web scraping des données web issues du jeu crescendo ou eurodreams de la FDG, ajout des résultats dans un fichier CSV correspondant existant ou non. Entrainement d'un modèle NNCLTLLM sur la base des données recueillies, affinage des hyperparamètres et estimation des futures séries de numéros."
metadata:
  author: cpht
  version: "2.0"
---

# Analyse de série temporelle pour la prédiction futur de jeu de hasard 

## Warning

You are not allowed to write your own script, if a script failed you should report it to the user and say: "Demander a Chris de corriger le script"

## Input Format

Un fichier csv, portant le nom eurodreams.csv ou crescendo.csv.
Chaque fichier comportera les colonnes suivantes:

Cresendo:

- **Date**: Date du tirage, cette date est la même pour "7" tirages consécutifs sur une journée au format YYYY/MM/DD
- **N1**: numero "1" 
- **N2**: numero "2"
- **N3**: numero "3"
- **N4**: numero "4"
- **N5**: numero "5" 
- **N6**: numero "6" 
- **N7**: numero "7" 
- **N8**: numero "8"
- **N9**: numero "9
- **N10**: numero "10"

Eurodreams:

- **Date**: Date du tirage au format YYYY/MM/DD
- **N1**: numero "1"
- **N2**: numero "2"
- **N3**: numero "3"
- **N4**: numero "4" 
- **N5**: numero "5"
- **N6**: numero "6 ""
- **étoile**: numero additionel 

## Workflow

### Training

** Etape 0: Scrapping des données

Si l'utilisateur demande explicitement a récupérer les données des derniers tirages:
1.Regarder la date la plus récente dans le fichier csv scripts/data/cresendo.csv ou scripts/data/eurodreams.csv qui se trouve à la dernière ligne, si le fichier n'existe pas le créer dans `/home/claude/` osu sle nom cresendo.csv ou eurodreams.csv
2.Faire une recherche web sur https://tirage-gagnant.com pour connaitre les tirage manquant depuis cette date
3.Ajouter au csv pour le jeu associé: eurdreams.csv ou cresendo.csv

Sinon:
Passé à l'Etape "1"

** Etape 1: Vérifier la disponibilité des données

Vérifier que les données sont accessibles en fonction de la demande

```bash
find scripts/data/cresendo.csv
```
Et Copier le csv dans `/home/claude/`

ou

```bash
find scripts/data/eurodreams.csv
```
Et Copier le csv dans `/home/claude/`

** Etape 2: Procéder a l'entrainement du modèle

Pour crescendo:
```bash
python3 main.py --file /home/claude/crescendo.csv
```
ou

Pour crescendo:
```bash
python3 main.py --file /home/claude/eurodreams.csv
```

** Etape 3: 

A partir des sorties scripts/results/resultats_finaux.csv, scripts/results/train_log.csv, scripts/results/canal_log.csv, new_prediction_example.png, training_history.png
Produit un csv avec 2 feuilles reprsentant respectivement les logs d'entrainement et l'historique graphique, le resultat par canal, les résultats finaux et enfin les prédictions

### Recheche des meilleurs paramètres

```bash
python3 main.py --file /home/claude/eurodreams.csv
```

## Output Files

```
results/
├── train_log.csv		 # All test results and statistics
├── canal_log.csv		 # Human-readable findings
├── resultats_finaux.csv # Internal state for plot synchronization
└── plots/
    ├── new_prediction.png
    └── training_history.png
```

## References

## Dependencies

Install librairy in requirement.txt

```bash
pip install -r scripts/requirement.txt
```
